"""个人工作台 · 本地服务

作用：一边托管页面，一边把浏览器里的改动自动写进同目录的 data.json。
页面里每新增/修改/删除一条记录，都会立刻落盘，关掉浏览器也不会丢。

用法：
    python server.py          # 打开 http://127.0.0.1:8000/workbench-desktop.html
    python server.py 8080     # 换端口

按 Ctrl+C 停止。停止后页面就打不开了，数据仍在 data.json 里。
"""

import json
import os
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(ROOT, "data.json")
API_PATH = "/api/data"


class WorkbenchHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def end_headers(self):
        # 本地自用，一律不缓存：改完代码刷新就能看到
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def _path(self):
        return self.path.split("?", 1)[0]

    def _send_json(self, code, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self._path() != API_PATH:
            return super().do_GET()

        if not os.path.exists(DATA_FILE):
            return self._send_json(404, {"error": "还没有数据文件"})

        with open(DATA_FILE, "rb") as f:
            body = f.read()
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self._path() != API_PATH:
            return self.send_error(404, "Not Found")

        try:
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length)
            payload = json.loads(raw.decode("utf-8"))   # 先校验是合法 JSON

            # 落盘时格式化成带缩进的多行，方便直接打开阅读
            pretty = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")

            tmp = DATA_FILE + ".tmp"
            with open(tmp, "wb") as f:
                f.write(pretty)
            os.replace(tmp, DATA_FILE)          # 原子替换，避免写到一半坏掉
        except Exception as exc:
            return self._send_json(400, {"ok": False, "error": str(exc)})

        self._send_json(200, {"ok": True})

    def log_message(self, fmt, *args):
        sys.stdout.write("%s  %s\n" % (self.address_string(), fmt % args))
        sys.stdout.flush()


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    server = ThreadingHTTPServer(("127.0.0.1", port), WorkbenchHandler)
    print("个人工作台已启动：http://127.0.0.1:%d/workbench-desktop.html" % port)
    print("数据文件：%s" % DATA_FILE)
    print("按 Ctrl+C 停止\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止，数据保留在 data.json 中")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()